﻿namespace Storage
{
    /// <author>
    /// Jacob Cholewa (jbec@itu.dk)
    /// </author>
    public interface IEntityDto
    {
        int Id { set; get; }
    }
}
