﻿namespace InMemoryStorage
{
    interface ISaveable
    {
        void SaveChanges();
    }
}
