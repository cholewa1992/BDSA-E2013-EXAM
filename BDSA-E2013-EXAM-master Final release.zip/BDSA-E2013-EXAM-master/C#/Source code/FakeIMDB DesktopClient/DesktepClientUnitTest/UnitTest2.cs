﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DesktepClientUnitTest
{
    [TestClass]
    public class SearchServiceTest
    {
        [TestMethod]
        public void SearchServiceNullTest()
        {
        }
    }
}
