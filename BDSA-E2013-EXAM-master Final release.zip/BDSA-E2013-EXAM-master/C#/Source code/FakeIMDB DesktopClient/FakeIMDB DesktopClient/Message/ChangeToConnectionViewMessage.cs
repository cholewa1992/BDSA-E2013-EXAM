﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakeIMDB_DesktopClient.Message
{
    /// <summary>
    /// Message for changing to ConnectionView
    /// </summary>
    /// <author>
    /// Mathias Kindsholm Pedersen(mkin@itu.dk)
    /// </author>
    class ChangeToConnectionViewMessage
    {
    }
}
