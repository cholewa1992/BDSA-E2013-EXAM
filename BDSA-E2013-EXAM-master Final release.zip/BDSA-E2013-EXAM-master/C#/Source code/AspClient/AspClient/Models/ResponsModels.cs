﻿namespace AspClient.Models
{

    public class ResponsModel
    {
        public string Msg { get; set; }
    }
}
