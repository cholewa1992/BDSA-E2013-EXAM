﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AspClient.Models
{
    public class ErrorModel
    {
        public string ErrorCode { get; set; }
        public string ErrorMsg { get; set; }
    }
}
