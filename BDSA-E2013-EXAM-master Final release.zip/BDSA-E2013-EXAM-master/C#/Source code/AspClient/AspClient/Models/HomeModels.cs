﻿namespace AspClient.Models
{
    public class SearchModel
    {
        public string SearchString{ get; set; }
    }
}